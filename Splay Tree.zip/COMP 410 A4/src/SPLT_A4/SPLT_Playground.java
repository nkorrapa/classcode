package SPLT_A4;

public class SPLT_Playground {
  public static void main(String[] args){
  // genTest();
	//all these are null
  // remove7();
   contains1();
   //containsn0();
	 // containsn1();
	
  
  }
  private static void containsn1() {
	// TODO Auto-generated method stub
	
}
private static void size3() {
	// TODO Auto-generated method stub
	SPLT s=new SPLT();
		s.insert("a");
		s.insert("a");
		System.out.println(s.size());
}
private static void containsn0() {
	// TODO Auto-generated method stub
	
}
private static void contains1() {
	// TODO Auto-generated method stub
	SPLT c = new SPLT();
	c.insert("B");
	printLevelOrder(c);
	c.insert("A");
	printLevelOrder(c);
	c.insert("D");
	printLevelOrder(c);
	c.insert("C");
	printLevelOrder(c);
	c.insert("E");
	printLevelOrder(c);
	c.remove("D");
	printLevelOrder(c);
	System.out.println(c.contains("D"));
	printLevelOrder(c);
	System.out.println(c.contains("C"));
	printLevelOrder(c);
	System.out.println(c.contains("E"));
	printLevelOrder(c);
	System.out.println(c.root.data);
	
}
private static void insert5() {
	// TODO Auto-generated method stub
	SPLT y=new SPLT();
	y.insert("A");
	//printLevelOrder(y);
	y.insert("B");
	//printLevelOrder(y);
	y.insert("C");
	//printLevelOrder(y);
	y.insert("A");
	printInOrder(y.root);
	System.out.println("root" + y.root.data);
	System.out.println(y.size());
}
private static void remove7() {
	SPLT r=new SPLT();
	
	
}


  public static void genTest(){
    SPLT tree= new SPLT();
    tree.insert("hello");
    tree.insert("world");
    tree.insert("my");
   tree.insert("name");
   tree.insert("is");
    tree.insert("blank");
   tree.remove("hello");
    System.out.println("size is "+tree.size());
    
    printLevelOrder(tree);
//    System.out.println(tree.root.data);
//    System.out.println(tree.root.left.data);
//    System.out.println(tree.root.left.right.data);
    
  }
  public static void test1(){
	  SPLT x=new SPLT();
	  x.insert("hi");
	  x.insert("how");
//	  System.out.println(x.root.data);
//	  System.out.println(x.root.left.data);
	printLevelOrder(x);
  }

    static void printLevelOrder(SPLT tree){ 
    //will print your current tree in Level-Order...Requires a correct height method
    //https://en.wikipedia.org/wiki/Tree_traversal
      int h=tree.getRoot().getHeight();
      for(int i=0;i<=h;i++){
        System.out.print("Level "+i+":");
        printGivenLevel(tree.getRoot(), i);
        System.out.println();
      }
      
    }
    static void printGivenLevel(BST_Node root,int level){
      if(root==null)return;
      if(level==0)System.out.print(root.data+" ");
      else if(level>0){
        printGivenLevel(root.left,level-1);
        printGivenLevel(root.right,level-1);
      }
    }
   static void printInOrder(BST_Node root){
      if(root!=null){
      printInOrder(root.getLeft());
      System.out.print(root.getData()+" ");
      printInOrder(root.getRight());
      }
  }
  
}
