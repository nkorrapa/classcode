package SPLT_A4;

public class SPLT implements SPLT_Interface {
	 BST_Node root;
	private int size;
	private BST_Node node;

	public SPLT() {
		this.size = 0;
	}

	public BST_Node getRoot() { // please keep this in here! I need your root
								// node to test your tree!
		return root;
	}

	@Override
	public void insert(String s) {
		// TODO Auto-generated method stub
		if (empty()) {
			root = new BST_Node(s);
			size += 1;
		} else {//use justMade to check for duplicates
			root = root.insertNode(s);
			if(root.justMade){
				root.justMade=false;
				size += 1;
			}
		}
	}

	@Override
	public void remove(String s) {
		if (contains(s)){
			root.removeNode(s);
			size--;
			
		}
		// TODO Auto-generated method stub

	}

	@Override
	public String findMin() {
		// TODO Auto-generated method stub
		root = root.findMin();
		return root.data;
	}

	@Override
	public String findMax() {
		root = root.findMax();
		return root.data;

	}

	@Override
	public boolean empty() {
		if (root == null ||size==0 ) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean contains(String s) {
		if (empty()) {
			return false;
		}
		root = root.containsNode(s);
		if (root.data == s) {
			return true;
		} else {
			return false;
		}

	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public int height() {
		if(empty()){
			return -1;
		}else{
		BST_Node left = root.left;
		BST_Node right = root.right;
		int l = 0;
		int r = 0;
		if (left != null)
			l += left.getHeight() + 1;
		if (right != null)
			r += right.getHeight() + 1;
		return Integer.max(l, r);
		}
	}

}
