package SPLT_A4;

public class BST_Node {
	String data;
	BST_Node left;
	BST_Node right;

	BST_Node par; // parent...not necessarily required, but can be useful in
					// splay tree
	boolean justMade; // could be helpful if you change some of the return types
						// on your BST_Node insert.
	// I personally use it to indicate to my SPLT insert whether or not we
	// increment size.

	BST_Node(String data) {
		this.data = data;
		this.justMade = false;
	}

	BST_Node(String data, BST_Node left, BST_Node right, BST_Node par) { // feel
																			// free
																			// to
																			// modify
																			// this
																			// constructor
																			// to
																			// suit
																			// your
																			// needs
		this.data = data;
		this.left = left;
		this.right = right;
		this.par = par;
		this.justMade = false;
	}

	public String getData() {
		return data;
	}

	public BST_Node getLeft() {
		return left;
	}

	public BST_Node getRight() {
		return right;
	}

	public BST_Node containsNode(String s) { // it was me
		if (data.equals(s)) {
			splay(this);
			return this;
		}
		if (data.compareTo(s) > 0) {// s lexiconically less than data
			if (left == null) {
				return splay(this);
				
			}
			return left.containsNode(s);
		}
		if (data.compareTo(s) < 0) {
			if (right == null) {

				return splay(this);
				
			}
			return right.containsNode(s);
		}
		return null; // shouldn't hit
	}
	
	
	
	
	public BST_Node insertNode(String s) {
		this.justMade=false;
			if (data.compareTo(s) > 0) {
				if (left == null) {
					left = new BST_Node(s);
					left.par = this;
					left.justMade = true;
					return splay(left);

				}
				return left.insertNode(s);
			} else if (data.compareTo(s) < 0) {
				if (right == null) {
					right = new BST_Node(s);
					right.par = this;
					right.justMade = true;
					return splay(right);
				}
				return right.insertNode(s);
			}
			justMade = false;
			return splay(this);
			//return ;// ie we have a duplicate
		
	}

	public boolean removeNode(String s) { // DIO
		if (data == null)
			return false;
		if (data.equals(s)) {
			if (left != null) {
				data = left.max().data;
				left.removeNode(data);
				if (left.data == null)
					left = null;
			} else if (right != null) {
				data = right.min().data;
				right.removeNode(data);
				if (right.data == null)
					right = null;
			} else
				data = null;
			return true;
		} else if (data.compareTo(s) > 0) {
			if (left == null)
				return false;
			if (!left.removeNode(s))
				return false;
			if (left.data == null)
				left = null;
			return true;
		} else if (data.compareTo(s) < 0) {
			if (right == null)
				return false;
			if (!right.removeNode(s))
				return false;
			if (right.data == null)
				right = null;
			return true;
		}
		return false;
	}

	public BST_Node findMin() {
		if (left != null) {

			return left.findMin();
		}
		splay(this);
		return this;
	}

	// create new min max and use that in remove
	public BST_Node findMax() {
		if (right != null) {

			return right.findMax();
		}
		splay(this);
		return this;
	}

	public BST_Node min() {
		if (left != null)
			return left.min();
		return this;
	}

	public BST_Node max() {
		if (right != null)
			return right.max();
		return this;
	}

	public int getHeight() {
		int l = 0;
		int r = 0;
		if (left != null)
			l += left.getHeight() + 1;
		if (right != null)
			r += right.getHeight() + 1;
		return Integer.max(l, r);
	}

	public String toString() {
		return "Data: " + this.data + ", Left: "
				+ ((this.left != null) ? left.data : "null") + ",Right: "
				+ ((this.right != null) ? right.data : "null");
	}

	private BST_Node splay(BST_Node node) {
		// zig zag
		if (node.par == null) {
			return node;
		} else if (node.par != null && node.par.par == null) {
			if (node.par.right == node) {
				rotateLeft(node);
				return splay(node);
			} else if (node.par.left == node) {
				rotateRight(node);
				return splay(node);
			}
			// zig zig zag zag
		} else if (node.par.par != null) {
			if (node.par.par.right == node.par && node.par.right == node) {
				rotateLeft(node.par);
				rotateLeft(node);
				return splay(node);
			} else if (node.par.par.left == node.par && node.par.left == node) {
				rotateRight(node.par);
				rotateRight(node);
				return splay(node);
			} else if (node.par.par.right == node.par// zig zag zag zig
					&& node.par.left == node) {
				rotateRight(node);
				rotateLeft(node);
				return splay(node);
			} else if (node.par.par.left == node.par
					&& node.par.right == node) {
				rotateLeft(node);
				rotateRight(node);
				return splay(node);
			}

		}

		return node;

	}

	// you could have this return or take in whatever you want..so long as it
	// will do the job internally. As a caller of SPLT functions, I should
	// really have no idea if you are "splaying or not"
	// I of course, will be checking with tests and by eye to make sure you are
	// indeed splaying
	// Pro tip: Making individual methods for rotateLeft and rotateRight might
	// be a good idea!
	private void rotateLeft(BST_Node current) {// use for r
		BST_Node gparent = current.par.par;

		BST_Node parent = current.par;
		if (gparent != null) {
			if (gparent.left == parent) {
				gparent.left = current;

			} else {
				gparent.right = current;

			}
		}
		current.par = gparent;
		if (current.left != null) {
			current.left.par = parent;
		}

		parent.right = current.left;
		current.left = parent;
		parent.par = current;

	}

	private void rotateRight(BST_Node current) {// use for l
		BST_Node gparent = current.par.par;

		BST_Node parent = current.par;
		if (gparent != null) {
			if (gparent.left == parent) {
				gparent.left = current;

			} else {
				gparent.right = current;

			}
		}
		current.par = gparent;
		if (current.right != null) {
			current.right.par = parent;
		}
		parent.left = current.right;
		parent.par = current;
		current.right = parent;
	}
}
