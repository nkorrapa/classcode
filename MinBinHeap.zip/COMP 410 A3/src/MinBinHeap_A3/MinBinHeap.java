package MinBinHeap_A3;

public class MinBinHeap implements Heap_Interface {
	private EntryPair[] array; // load this array
	private int size = 0;
	private int parentindex;
	private int lchildindex;
	private int rchildindex;
	private int insertindex;
	private static final int arraySize = 10000; // Everything in the array will
												// initially be null. This is
												// ok! Just build out from
												// array[1]

	public MinBinHeap() {
		this.array = new EntryPair[arraySize];
		array[0] = new EntryPair(null, -100000); // 0th will be unused for
													// simplicity of
													// child/parent
													// computations... the
													// book/animation page both
													// do this.
	}

	// Please do not remove or modify this method! Used to test your entire
	// Heap.
	@Override
	public EntryPair[] getHeap() {
		return this.array;
	}

	@Override
	public void insert(EntryPair entry) {
		if (size == array.length - 1) {
			System.out.println("heap is full");
		} else if(entry.getValue()==null){
			System.out.println("Entry is null");
		}else{
			size++;
			insertindex = size;
			array[insertindex] = entry;
			bubbleUp(insertindex);
		}
	}
	

	@Override
	public void delMin() {
		if (size == 0) {
			System.out.println("heap is empty");
		} else {
			array[1] = array[size];
			array[size] = null;
			size--;
			if (size > 0) {
				bubbleDown(1);
			}
		}

	}

	@Override
	public EntryPair getMin() {
		if (size > 0) {
			return array[1];
		} else {
			return null;
		}
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public void build(EntryPair[] entries) {
		
		size = entries.length;
		if (size == 0) {
			System.out.println("There are no entries");
		} else {
			for (int i = 0; i < size; i++) {
				if(entries[i].getValue()==null){
					System.out.println("Entry " + i + " in entries is null.");
					size--;
				}else{
				array[i + 1] = entries[i];
				}
			}
			for (int k = size / 2; k > 0; k--) {

				bubbleDown(k);
			}
		}
	}

	private void bubbleUp(int insertindex) {// bubbles entry into place
		EntryPair temp;
		if (insertindex >= 1) {
			parentindex = insertindex / 2;
			if (parentindex == 0) {
				return;
			} else {
				if (array[parentindex].getPriority() > array[insertindex]
						.getPriority()) {
					temp = array[parentindex];
					array[parentindex] = array[insertindex];
					array[insertindex] = temp;
					bubbleUp(parentindex);
				}
			}
		}
	}

	private void bubbleDown(int index) {

		int minindex;
		EntryPair temp;
		rchildindex = (2 * index) + 1;
		lchildindex = 2 * index;

		if (lchildindex > size) {//
			return;
		} else if (lchildindex == size) {
			minindex = lchildindex;
		} else {
			if (array[lchildindex].getPriority() <= array[rchildindex]
					.getPriority()) {
				minindex = lchildindex;
			} else {
				minindex = rchildindex;
			}
		}
		if (array[index].getPriority() > array[minindex].getPriority()) {
			temp = array[minindex];
			array[minindex] = array[index];
			array[index] = temp;
		}
		bubbleDown(minindex);

	}
}